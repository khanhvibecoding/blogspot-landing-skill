# Plan

## Phase 1: Intake

Đọc brief người dùng và trích xuất:

- Tên thương hiệu.
- Sản phẩm/dịch vụ.
- Khách hàng mục tiêu.
- Pain point.
- Lợi ích chính.
- Tính năng.
- Bằng chứng/xác thực.
- Giá/ưu đãi.
- CTA.
- Link CTA.
- Tone.
- Màu sắc.
- Hình ảnh/logo.
- Ràng buộc kỹ thuật.

Nếu thiếu, tự giả định trong trường `assumptions`.

## Phase 2: Spec

Tạo `landing-spec.json` theo schema:

- `brand`
- `offer`
- `audience`
- `positioning`
- `sections`
- `design`
- `seo`
- `cta`
- `assets`
- `constraints`
- `assumptions`

## Phase 3: Copywriting

Viết nội dung theo khung:

1. Hero: nói thẳng kết quả.
2. Problem: nhắc đúng nỗi đau.
3. Benefits: biến tính năng thành lợi ích.
4. Features: chỉ rõ sản phẩm làm được gì.
5. Workflow: người dùng bắt đầu như nào.
6. Proof: demo, số liệu, testimonial nếu có.
7. Pricing/Offer: gói dịch vụ hoặc lời mời.
8. FAQ: phá rào cản mua hàng.
9. Final CTA: chốt.

## Phase 4: Template

Sinh Blogger XML:

- Inline CSS.
- Static landing markup.
- Hidden Blogger section để template hợp lệ.
- Responsive layout.
- CTA link thật hoặc fallback `#contact`.

## Phase 5: Preview

Sinh `preview.html` bằng cách:

- Lấy CSS trong `b:skin`.
- Chuyển Blogger XML thành HTML local.
- Loại bỏ tag Blogger chỉ dành cho runtime.
- Giữ layout và copy càng giống template thật càng tốt.

## Phase 6: QA

Chạy kiểm thử bằng `tools/validate_template.py`.

Nếu lỗi:
- Sửa template.
- Sinh preview lại.
- Kiểm thử lại.

## Phase 7: Final

Giao:

- File XML.
- File preview.
- QA report.
- Ghi chú import vào Blogger.
