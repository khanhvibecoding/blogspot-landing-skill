# Loop Protocol

Agent phải chạy theo vòng sau.

## Loop 0: Clarify

Chỉ hỏi lại nếu thiếu một trong các dữ liệu sống còn:

- Sản phẩm/dịch vụ là gì?
- CTA đi đâu?
- Ngôn ngữ nào?
- Có ràng buộc pháp lý/ngành nhạy cảm không?

Nếu không thiếu, tự tiếp tục.

## Loop 1: Build Spec

Sinh `landing-spec.json`.

Checklist:
- Có brand name.
- Có target audience.
- Có offer.
- Có CTA.
- Có sections.
- Có SEO title/description.
- Có assumptions nếu thiếu dữ liệu.

Nếu thiếu, sửa spec.

## Loop 2: Generate Template

Sinh `landing-template.xml`.

Checklist:
- XML declaration.
- DOCTYPE.
- Blogger namespaces.
- `<b:skin><![CDATA[` CSS.
- Responsive CSS.
- H1.
- CTA.
- Hidden Blog widget.

Nếu thiếu, sửa.

## Loop 3: Preview

Sinh `preview.html`.

Checklist:
- Mở được bằng trình duyệt.
- Giao diện không trắng.
- CSS được nhúng.
- Link CTA còn hoạt động.
- Không còn Blogger tag lạ hiện ra như chữ thô.

Nếu lỗi, sửa tool hoặc template.

## Loop 4: QA

Chạy validator.

Nếu `passed = false`, đọc lỗi, sửa và chạy lại.

## Loop 5: Conversion Review

Tự phê bình landing page:

- Headline đã rõ kết quả chưa?
- CTA có nổi chưa?
- Section đầu có nói đúng vấn đề chưa?
- Có quá dài không?
- Mobile có dễ đọc không?
- Có claim nào quá đà không?

Sửa nếu cần.

## Loop 6: Final Lock

Chỉ khóa bản cuối khi:
- QA pass.
- Preview có.
- Template có.
- Spec có.
- Change log có.

Nếu không pass sau 3 vòng, xuất bản kèm danh sách lỗi còn lại.
