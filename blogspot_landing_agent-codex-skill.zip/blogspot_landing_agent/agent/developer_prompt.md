# Developer Prompt cho Agent

## Output bắt buộc

Tạo các file:

- output/landing-spec.json
- output/landing-template.xml
- output/preview.html
- output/qa-report.json
- output/change-log.md

## Blogger XML skeleton bắt buộc

Template phải có dạng gần với cấu trúc này:

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html b:css='false'
      b:defaultwidgetversion='2'
      b:layoutsVersion='3'
      b:responsive='true'
      expr:dir='data:blog.languageDirection'
      expr:lang='data:blog.locale'
      xmlns='http://www.w3.org/1999/xhtml'
      xmlns:b='http://www.google.com/2005/gml/b'
      xmlns:data='http://www.google.com/2005/gml/data'
      xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
  <meta content='width=device-width, initial-scale=1' name='viewport'/>
  <title><data:blog.pageTitle/></title>
  <b:skin><![CDATA[
    /* CSS ở đây */
  ]]></b:skin>
</head>
<body>
  <!-- Landing page HTML ở đây -->
  <b:section class='hidden-section' id='blogger-required-section' maxwidgets='1' showaddelement='false'>
    <b:widget id='Blog1' locked='true' title='Blog Posts' type='Blog' visible='false'/>
  </b:section>
</body>
</html>
```

## Quy tắc HTML

- Dùng semantic HTML: header, main, section, footer.
- Mỗi section phải có id rõ ràng.
- Không dùng form submit nội bộ nếu không có endpoint.
- CTA phải là `<a>`, không chỉ là `<button>`.
- Logo có thể là text nếu không có file ảnh.
- Hình ảnh nên có `alt`.

## Quy tắc CSS

- CSS inline trong `<b:skin><![CDATA[...]]></b:skin>`.
- Dùng CSS variables ở `:root`.
- Có breakpoint cho mobile.
- Không ép chiều cao cứng gây vỡ layout.
- Không dùng font ngoài trừ khi người dùng yêu cầu.

## Quy tắc JS

- Không bắt buộc dùng JS.
- Nếu có JS, đặt cuối body trong `<script>`.
- Chỉ dùng JS nhẹ cho menu, smooth scroll hoặc FAQ accordion.
- Không tracking nếu người dùng không yêu cầu.

## Quy tắc SEO

Phải có:

- meta description.
- open graph title.
- open graph description.
- open graph type.
- canonical bằng `expr:href='data:blog.canonicalUrl'` nếu dùng được.
- heading H1 duy nhất.

## Quy tắc kiểm thử

Sau khi sinh file, phải kiểm:

- XML parse.
- Có namespace `b`, `data`, `expr`.
- Có `b:skin`.
- Có viewport.
- Có H1.
- Có CTA.
- Có responsive breakpoint.
- Không placeholder.
- File size hợp lý.
