# Output Contract

## landing-spec.json

JSON UTF-8. Không comment. Phải match schema trong `schemas/landing_spec.schema.json`.

## landing-template.xml

Blogger XML hoàn chỉnh.

Không được chỉ xuất HTML thường. Blogger không phải cái thùng rác để ném HTML vào rồi cầu nguyện.

## preview.html

HTML thường, dùng để xem local.

## qa-report.json

Cấu trúc:

```json
{
  "passed": true,
  "checks": [
    {
      "name": "xml_parse",
      "passed": true,
      "details": "OK"
    }
  ],
  "warnings": [],
  "errors": []
}
```

## change-log.md

Ghi:

- Brief nhận được.
- Assumptions.
- Các vòng sửa.
- Lỗi đã fix.
- Hướng dẫn import.
