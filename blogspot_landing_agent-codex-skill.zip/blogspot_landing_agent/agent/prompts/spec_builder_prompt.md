# Spec Builder Prompt

Từ intake, tạo `landing-spec.json` hợp lệ theo schema.

Yêu cầu:

- JSON thuần.
- Không markdown.
- Không comment.
- Không placeholder.
- Mọi section phải có `id`, `type`, `heading`, `body`, `items`.
- CTA phải có text và url.
- SEO description dưới 160 ký tự nếu có thể.
- Ghi mọi giả định vào `assumptions`.

Nếu sản phẩm thuộc lĩnh vực nhạy cảm như y tế, tài chính, pháp lý, không được tạo claim chắc chắn quá mức. Dùng ngôn ngữ thận trọng.
