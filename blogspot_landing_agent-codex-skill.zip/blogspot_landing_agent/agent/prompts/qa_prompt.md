# QA Prompt

Kiểm thử output theo checklist:

## XML/Blogger

- XML parse được?
- Có `xmlns:b`?
- Có `xmlns:data`?
- Có `xmlns:expr`?
- Có `b:skin`?
- Có `b:section`?
- Có widget Blog ẩn?

## Landing page

- Có H1?
- Có CTA?
- Có hero?
- Có final CTA?
- Có FAQ?
- Có meta description?
- Có responsive breakpoint?

## Copy

- Headline có nói rõ kết quả?
- CTA có hành động rõ?
- Có bằng chứng hoặc lý do tin?
- Có câu nào phóng đại quá mức không?
- Có placeholder không?

## Preview

- Preview mở được?
- Layout có CSS?
- Không lộ tag Blogger lạ?

Trả về `qa-report.json`.
Nếu có lỗi, phân loại:
- critical: phải sửa ngay.
- warning: nên sửa.
- note: ghi chú.
