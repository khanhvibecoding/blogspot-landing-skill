# Revision Prompt

Bạn nhận `qa-report.json` và file hiện tại.

Hãy sửa theo thứ tự ưu tiên:

1. Lỗi XML khiến Blogger không lưu.
2. Lỗi thiếu namespace/Blogger section.
3. Lỗi responsive.
4. Lỗi CTA/SEO.
5. Lỗi copywriting.
6. Lỗi thẩm mỹ.

Không viết lại toàn bộ nếu chỉ cần sửa nhỏ.
Sau khi sửa, cập nhật `change-log.md`.
