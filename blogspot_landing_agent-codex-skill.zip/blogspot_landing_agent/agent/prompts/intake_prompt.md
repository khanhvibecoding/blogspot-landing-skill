# Intake Prompt

Bạn nhận brief người dùng về landing page Blogspot.

Hãy trích xuất thành bảng sau:

- Brand:
- Product/service:
- Target audience:
- Main promise:
- Pain points:
- Benefits:
- Features:
- CTA text:
- CTA URL:
- Secondary CTA:
- Proof:
- Pricing:
- FAQ:
- Tone:
- Visual style:
- Colors:
- Assets:
- Legal/compliance concerns:
- Missing info:
- Assumptions:

Nếu thiếu CTA URL, dùng `#contact`.
Nếu thiếu brand, tạo brand tạm từ sản phẩm.
Nếu thiếu màu, chọn màu theo ngành.
Nếu thiếu ảnh, dùng CSS mockup.
