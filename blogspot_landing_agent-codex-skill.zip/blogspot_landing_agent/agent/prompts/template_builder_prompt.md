# Template Builder Prompt

Từ `landing-spec.json`, tạo `landing-template.xml`.

Yêu cầu bắt buộc:

- Blogger XML hoàn chỉnh.
- Có XML declaration.
- Có DOCTYPE html.
- Có Blogger namespaces.
- Có `<b:skin><![CDATA[` chứa toàn bộ CSS.
- Có header, main, footer.
- Có H1 duy nhất.
- Có CTA chính và CTA phụ nếu có.
- Có FAQ accordion bằng `<details><summary>`.
- Có section contact/final CTA.
- Có hidden `b:section` và `Blog` widget.
- Không để placeholder.

Style:

- Dùng CSS variables.
- Responsive mobile-first.
- Dùng card, grid, spacing rõ.
- Không import Tailwind/Bootstrap.
- Không dùng ảnh ngoài nếu không có trong spec.
