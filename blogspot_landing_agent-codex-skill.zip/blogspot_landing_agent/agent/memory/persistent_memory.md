# Persistent Memory

Các quy tắc agent phải nhớ giữa các lần chạy.

## Default Landing Page Structure

1. Hero
2. Problem
3. Benefits
4. Features
5. How it works
6. Proof
7. Pricing/Offer
8. FAQ
9. Final CTA
10. Footer

## Default Blogger Strategy

- Chỉ dùng trang chủ.
- Ẩn Blog widget.
- Không phụ thuộc bài đăng.
- CSS inline trong b:skin.
- CTA link ngoài.
- Preview tách riêng.

## Default Copy Style

- Rõ lợi ích.
- Ít sáo rỗng.
- Nói thẳng nỗi đau.
- CTA cụ thể.
- Không hô hào “số 1”, “tốt nhất” nếu không có bằng chứng.

## Default Technical Choices

- No external CSS framework.
- No build step.
- No analytics unless requested.
- No forms unless endpoint provided.
- System font stack.
- Vanilla CSS/JS only.
