# Session Memory Template

## Project

- Date:
- Client/User:
- Brand:
- Product:
- Target audience:
- CTA:

## Requirements

- Must have:
- Nice to have:
- Must avoid:

## Assumptions

1.
2.
3.

## Generated Files

- landing-spec.json:
- landing-template.xml:
- preview.html:
- qa-report.json:

## QA History

### Round 1

- Errors:
- Fixes:

### Round 2

- Errors:
- Fixes:

### Final

- Passed:
- Remaining warnings:
