# Blogger Constraints

## Những thứ Blogger cần

- XML hợp lệ.
- Namespace:
  - `xmlns:b`
  - `xmlns:data`
  - `xmlns:expr`
- Ít nhất một `b:section`.
- Thường nên có một `Blog` widget, kể cả khi ẩn.

## Những thứ dễ gây lỗi

- Dùng ký tự `&` không escape thành `&amp;`.
- CSS chứa `]]>` trong CDATA.
- Thẻ HTML không đóng.
- Attribute trùng nhau.
- Dán HTML thường mà không có namespace Blogger.
- Dùng script ngoài bị chặn hoặc tải chậm.
- Quên viewport làm mobile vỡ như niềm tin vào deadline.

## Khuyến nghị

- Dùng text logo nếu chưa có logo.
- Dùng CSS gradient thay ảnh hero nếu thiếu asset.
- Dùng CTA link ngoài.
- Chỉ dùng JS nhẹ.
- Tạo anchor sections: `#features`, `#pricing`, `#faq`, `#contact`.
- Không cần tạo bài viết.
