#!/usr/bin/env python3
"""
Validate a Blogger landing template.

Checks are intentionally practical, not academic. The user needs something
Blogger can swallow without choking, not a dissertation.
"""

from __future__ import annotations

import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def add_check(checks, name, passed, details):
    checks.append({"name": name, "passed": bool(passed), "details": details})


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: validate_template.py landing-template.xml [qa-report.json]")
        sys.exit(2)

    path = Path(sys.argv[1])
    report_path = Path(sys.argv[2]) if len(sys.argv) > 2 else None
    text = path.read_text(encoding="utf-8")

    checks = []
    warnings = []
    errors = []

    # XML parse
    try:
        ET.fromstring(text)
        add_check(checks, "xml_parse", True, "XML parsed successfully.")
    except ET.ParseError as e:
        add_check(checks, "xml_parse", False, str(e))
        errors.append(f"XML parse error: {e}")

    required_snippets = {
        "xml_declaration": "<?xml version=",
        "doctype": "<!DOCTYPE html>",
        "blogger_namespace_b": "xmlns:b=",
        "blogger_namespace_data": "xmlns:data=",
        "blogger_namespace_expr": "xmlns:expr=",
        "b_skin": "<b:skin><![CDATA[",
        "viewport": "name='viewport'",
        "b_section": "<b:section",
        "blog_widget": "type='Blog'",
    }

    for name, snippet in required_snippets.items():
        ok = snippet in text
        add_check(checks, name, ok, "Found." if ok else f"Missing snippet: {snippet}")
        if not ok:
            errors.append(f"Missing required Blogger/template element: {name}")

    h1_count = len(re.findall(r"<h1\b", text, re.I))
    add_check(checks, "single_h1", h1_count == 1, f"H1 count: {h1_count}")
    if h1_count != 1:
        errors.append(f"Expected exactly one H1, found {h1_count}.")

    cta_count = len(re.findall(r'class="[^"]*btn[^"]*"', text))
    add_check(checks, "cta_buttons", cta_count >= 2, f"CTA/button-like links found: {cta_count}")
    if cta_count < 2:
        errors.append("Expected at least 2 CTA/button links.")

    has_media = "@media" in text
    add_check(checks, "responsive_css", has_media, "Found @media breakpoint." if has_media else "No @media breakpoint found.")
    if not has_media:
        errors.append("Missing responsive CSS breakpoint.")

    placeholder_re = re.compile(r"(TODO|Lorem ipsum|\[insert\]|\{\{.*?\}\})", re.I)
    placeholders = placeholder_re.findall(text)
    add_check(checks, "no_placeholders", not placeholders, f"Placeholders found: {placeholders}" if placeholders else "No placeholders.")
    if placeholders:
        errors.append("Template still contains placeholders.")

    css_entity_re = re.compile(r"""content\s*:\s*['"]&(?:#\d+|#x[0-9a-f]+|[a-z]+);""", re.I)
    css_entities = css_entity_re.findall(text)
    add_check(
        checks,
        "css_content_entities",
        not css_entities,
        "No HTML entities used in CSS content." if not css_entities else f"Unsafe CSS content entities: {css_entities}",
    )
    if css_entities:
        errors.append("Use CSS Unicode escapes (for example \\2713), not HTML entities, inside CSS content.")

    desc_ok = "name='description'" in text or 'name="description"' in text
    add_check(checks, "meta_description", desc_ok, "Meta description found." if desc_ok else "Meta description missing.")
    if not desc_ok:
        warnings.append("Meta description missing.")

    size_kb = len(text.encode("utf-8")) / 1024
    size_ok = size_kb < 300
    add_check(checks, "file_size", size_ok, f"{size_kb:.1f} KB")
    if not size_ok:
        warnings.append(f"Template is large: {size_kb:.1f} KB.")

    # Basic anchor checks
    ids = set(re.findall(r'id="([^"]+)"', text))
    href_hashes = set(re.findall(r'href="#([^"]+)"', text))
    broken = sorted(h for h in href_hashes if h not in ids)
    add_check(checks, "internal_anchors", not broken, f"Broken internal anchors: {broken}" if broken else "Internal anchors OK.")
    if broken:
        warnings.append(f"Broken internal anchors: {broken}")

    passed = not errors
    report = {
        "passed": passed,
        "checks": checks,
        "warnings": warnings,
        "errors": errors,
    }

    report_json = json.dumps(report, ensure_ascii=False, indent=2)
    if report_path:
        report_path.write_text(report_json, encoding="utf-8")
    print(report_json)
    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
