#!/usr/bin/env python3
"""
Create local preview.html from Blogger XML template.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from blogger_template_generator import generate_preview


def main() -> None:
    if len(sys.argv) != 3:
        print("Usage: make_preview.py landing-template.xml preview.html")
        sys.exit(2)

    template = Path(sys.argv[1]).read_text(encoding="utf-8")
    preview = generate_preview(template)
    Path(sys.argv[2]).write_text(preview, encoding="utf-8")
    print(f"Preview written to {sys.argv[2]}")


if __name__ == "__main__":
    main()
