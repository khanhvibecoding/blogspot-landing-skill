#!/usr/bin/env python3
"""
Smoke test: generate sample output, validate it, create preview.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output" / "smoke-test"


def run(cmd):
    print("$", " ".join(str(x) for x in cmd))
    return subprocess.run(cmd, cwd=ROOT, text=True)


def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True, exist_ok=True)

    spec = ROOT / "examples" / "sample_spec.json"
    result = run([sys.executable, "src/agent_runtime.py", str(spec), str(OUT)])
    if result.returncode != 0:
        sys.exit(result.returncode)

    result = run([sys.executable, "tools/make_preview.py", str(OUT / "landing-template.xml"), str(OUT / "preview.html")])
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
