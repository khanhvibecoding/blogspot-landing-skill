#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 src/agent_runtime.py examples/sample_spec.json output
python3 tools/make_preview.py output/landing-template.xml output/preview.html
echo "Done. Open output/preview.html or copy output/landing-template.xml into Blogger."
