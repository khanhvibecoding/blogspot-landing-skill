---
name: blogspot-landing-agent
description: Create, revise, and QA high-conversion Blogger/Blogspot home-page landing templates. Use for Blogspot XML themes, single-page product landing pages, conversion funnels, local previews, Blogger compatibility fixes, and visual/entity encoding defects.
---

# Blogspot Landing Agent

Build a static, responsive Blogger home-page landing page. Generate and deliver:

- landing-spec.json
- landing-template.xml
- preview.html
- qa-report.json
- change-log.md

## Workflow

1. Read agent/AGENT.md, agent/blogger_constraints.md, and agent/output_contract.md.
2. Gather or infer the product, audience, primary CTA, secondary CTA, assets, and legal constraints. Record assumptions; never invent prices, testimonials, metrics, payment details, or contact links.
3. Pick one deliberate aesthetic direction. Avoid generic card-grid marketing pages; match the product and use a distinctive type, color and interaction system.
4. Build a valid spec using schemas/landing_spec.schema.json.
5. Run: python3 src/agent_runtime.py <spec.json> <output-dir>
6. Run the validator, inspect the preview where possible, revise, and re-run QA until it passes.

## Design rules

- Use one clear aesthetic direction: Ink & Paper, Neon Terminal, Brutalist Mono, Soft Luxury, Retro-Future, Swiss Precision, or Organic Flow.
- Keep one H1, a strong conversion CTA, product proof, technical differentiators, FAQ and final CTA.
- Use embedded CSS and light vanilla JS only. Prefer an animated mockup or a purposeful interactive detail over decorative blobs.
- Avoid generic AI aesthetics: no purple/blue-on-white gradient, default system/Inter/Roboto/Arial/Open Sans typography, repeated rounded cards, universal drop shadows, or placeholder copy.
- Use mobile-responsive fluid typography, restrained page-load/scroll reveals and meaningful hover feedback. Use external Google Fonts only when the brief permits external requests.

## Blogger and character-encoding safety

- Keep the required Blogger namespaces, b:skin, viewport metadata and hidden Blog widget section.
- Escape XML text/attributes correctly: &amp;, &lt;, &gt;, and attribute quotes. Do not put unescaped ampersands in XML.
- Do not use HTML entities inside CSS content, such as content: "&#10003;". Blogger may preserve the entity text and display &#10003; instead of a glyph.
- For CSS generated characters, use CSS Unicode escapes, e.g. content: "\\2713"; for a tick. Use the same approach for arrows, bullets, icons and other pseudo-element glyphs.
- Treat a visible &#...; or &name; string in the preview as a release-blocking rendering bug. Fix its context: CSS gets a Unicode escape; HTML/XML text gets correct escaping or a safe literal character.
- Never use ]]&gt; inside the b:skin CDATA block. Regenerate the preview and run QA after each encoding fix.

## Included resources

- src/: generator and runtime
- tools/: XML, anchor, entity validator and preview generator
- agent/: detailed Blogger workflow and prompts
- schemas/: landing spec schema

