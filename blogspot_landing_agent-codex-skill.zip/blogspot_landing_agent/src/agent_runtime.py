#!/usr/bin/env python3
"""
Minimal local runtime for the Blogspot Landing Page Agent.

This does not call an LLM by itself. The LLM part is defined in /agent prompts.
This runtime takes a completed landing-spec.json and creates:
- landing-template.xml
- preview.html
- qa-report.json
- change-log.md
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from blogger_template_generator import generate_template, generate_preview, load_spec


def run_validator(template_path: Path, report_path: Path) -> bool:
    cmd = [sys.executable, str(ROOT / "tools" / "validate_template.py"), str(template_path), str(report_path)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    return result.returncode == 0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("spec", help="Path to landing spec JSON")
    parser.add_argument("outdir", help="Output folder")
    args = parser.parse_args()

    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)

    spec = load_spec(args.spec)
    template = generate_template(spec)
    preview = generate_preview(template)

    spec_path = out / "landing-spec.json"
    template_path = out / "landing-template.xml"
    preview_path = out / "preview.html"
    report_path = out / "qa-report.json"
    changelog_path = out / "change-log.md"

    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    template_path.write_text(template, encoding="utf-8")
    preview_path.write_text(preview, encoding="utf-8")

    passed = run_validator(template_path, report_path)

    changelog_path.write_text(
        "\n".join([
            "# Change Log",
            "",
            "## Generation",
            "- Built landing-spec.json",
            "- Built landing-template.xml",
            "- Built preview.html",
            "- Ran QA validator",
            "",
            f"## QA",
            f"- Passed: {str(passed).lower()}",
            "",
            "## Blogger Import",
            "Blogger → Chủ đề → mũi tên cạnh Tùy chỉnh → Chỉnh sửa HTML → dán landing-template.xml → Lưu.",
            "",
        ]),
        encoding="utf-8",
    )

    print(f"Done. Output: {out}")
    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
