#!/usr/bin/env python3
"""
Blogger/Blogspot landing page template generator.

Input: landing-spec.json
Output: Blogger XML string and local preview HTML.

Only Python standard library is used. Because dependency hell is apparently
humanity's preferred recreational activity, so we avoid it here.
"""

from __future__ import annotations

import json
import re
from html import escape
from pathlib import Path
from typing import Any, Dict, List


PLACEHOLDER_RE = re.compile(r"(TODO|Lorem ipsum|\[insert\]|\{\{.*?\}\})", re.IGNORECASE)


def load_spec(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def h(text: Any) -> str:
    return escape(str(text or ""), quote=True)


def slug(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9_-]+", "-", text.strip().lower())
    return text.strip("-") or "section"


def normalize_items(items: Any) -> List[Any]:
    if not isinstance(items, list):
        return []
    return items


def css(spec: Dict[str, Any]) -> str:
    design = spec.get("design", {})
    primary = design.get("primary_color", "#7c3aed")
    accent = design.get("accent_color", "#22d3ee")
    bg = design.get("background", "#09090f")
    text = design.get("text_color", "#f8fafc")
    return f"""
:root {{
  --bg: {primary if False else bg};
  --bg-soft: rgba(255,255,255,.06);
  --card: rgba(255,255,255,.08);
  --card-strong: rgba(255,255,255,.12);
  --text: {text};
  --muted: rgba(248,250,252,.72);
  --line: rgba(255,255,255,.14);
  --primary: {primary};
  --accent: {accent};
  --shadow: 0 24px 80px rgba(0,0,0,.32);
  --radius: 28px;
  --max: 1120px;
}}
* {{ box-sizing: border-box; }}
html {{ scroll-behavior: smooth; }}
body {{
  margin: 0;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  color: var(--text);
  background:
    radial-gradient(circle at 20% 10%, color-mix(in srgb, var(--primary) 35%, transparent), transparent 32rem),
    radial-gradient(circle at 90% 0%, color-mix(in srgb, var(--accent) 25%, transparent), transparent 28rem),
    linear-gradient(180deg, var(--bg), #111827 52%, #07070b);
  min-height: 100vh;
}}
a {{ color: inherit; text-decoration: none; }}
img {{ max-width: 100%; height: auto; }}
.container {{ width: min(100% - 32px, var(--max)); margin-inline: auto; }}
.site-header {{
  position: sticky;
  top: 0;
  z-index: 50;
  backdrop-filter: blur(18px);
  background: rgba(9,9,15,.72);
  border-bottom: 1px solid var(--line);
}}
.nav {{
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 72px;
  gap: 20px;
}}
.logo {{
  display: inline-flex;
  align-items: center;
  gap: 10px;
  font-weight: 800;
  letter-spacing: -.03em;
}}
.logo-mark {{
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--primary), var(--accent));
  box-shadow: 0 12px 30px color-mix(in srgb, var(--primary) 35%, transparent);
}}
.nav-links {{
  display: flex;
  align-items: center;
  gap: 18px;
  color: var(--muted);
  font-size: 14px;
}}
.nav-links a:hover {{ color: var(--text); }}
.btn {{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  min-height: 46px;
  padding: 0 20px;
  border-radius: 999px;
  font-weight: 750;
  border: 1px solid var(--line);
  transition: transform .2s ease, border-color .2s ease, background .2s ease;
}}
.btn:hover {{ transform: translateY(-2px); }}
.btn-primary {{
  border: 0;
  background: linear-gradient(135deg, var(--primary), var(--accent));
  color: white;
  box-shadow: 0 18px 40px color-mix(in srgb, var(--primary) 35%, transparent);
}}
.btn-secondary {{ background: rgba(255,255,255,.06); }}
.hero {{
  padding: 92px 0 72px;
}}
.hero-grid {{
  display: grid;
  grid-template-columns: 1.05fr .95fr;
  gap: 46px;
  align-items: center;
}}
.eyebrow {{
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: var(--accent);
  background: rgba(255,255,255,.07);
  border: 1px solid var(--line);
  padding: 8px 12px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 750;
}}
h1, h2, h3 {{ margin: 0; letter-spacing: -.045em; line-height: 1.05; }}
h1 {{ font-size: clamp(42px, 7vw, 78px); margin-top: 20px; }}
h2 {{ font-size: clamp(32px, 4vw, 52px); }}
h3 {{ font-size: 20px; }}
.lead {{
  font-size: clamp(18px, 2vw, 22px);
  line-height: 1.65;
  color: var(--muted);
  margin: 24px 0 0;
}}
.hero-actions {{ display: flex; flex-wrap: wrap; gap: 14px; margin-top: 32px; }}
.hero-points {{
  display: grid;
  gap: 12px;
  margin-top: 30px;
  color: var(--muted);
}}
.hero-point::before {{
  content: "\\2713";
  color: var(--accent);
  font-weight: 900;
  margin-right: 10px;
}}
.mockup {{
  position: relative;
  padding: 18px;
  border-radius: var(--radius);
  background: linear-gradient(180deg, rgba(255,255,255,.16), rgba(255,255,255,.06));
  border: 1px solid var(--line);
  box-shadow: var(--shadow);
  overflow: hidden;
}}
.mockup::before {{
  content: "";
  position: absolute;
  inset: -40%;
  background: radial-gradient(circle, color-mix(in srgb, var(--accent) 18%, transparent), transparent 42%);
  transform: rotate(18deg);
}}
.mockup-screen {{
  position: relative;
  border-radius: 22px;
  background: #0b1020;
  border: 1px solid rgba(255,255,255,.15);
  padding: 18px;
  min-height: 440px;
  overflow: hidden;
}}
.mockup-top {{
  display: flex;
  gap: 8px;
  margin-bottom: 18px;
}}
.dot {{ width: 10px; height: 10px; border-radius: 50%; background: rgba(255,255,255,.35); }}
.timeline {{ display: grid; gap: 14px; }}
.timeline-card {{
  padding: 16px;
  border-radius: 18px;
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.1);
}}
.timeline-card strong {{ display: block; margin-bottom: 6px; }}
.timeline-card span {{ color: var(--muted); font-size: 14px; }}
.section {{ padding: 72px 0; }}
.section-head {{ max-width: 760px; margin-bottom: 28px; }}
.section-head p, .section-body {{ color: var(--muted); line-height: 1.7; font-size: 17px; }}
.grid {{
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 18px;
}}
.media-grid {{
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 18px;
}}
.media-card {{
  overflow: hidden;
  border: 1px solid var(--line);
  border-radius: 20px;
  background: var(--card);
}}
.media-card img {{ display: block; width: 100%; aspect-ratio: 16 / 10; object-fit: cover; }}
.media-card .media-copy {{ padding: 16px; }}
.media-card .media-copy p {{ color: var(--muted); line-height: 1.55; margin-bottom: 0; }}
.payment-card {{
  max-width: 560px;
  margin: 0 auto;
  padding: 24px;
  text-align: center;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: var(--card);
}}
.payment-card img {{
  display: block;
  width: min(100%, 460px);
  height: auto;
  margin: 0 auto 20px;
  background: white;
  border-radius: 14px;
}}
.card {{
  padding: 24px;
  border-radius: 24px;
  background: var(--card);
  border: 1px solid var(--line);
  box-shadow: 0 16px 50px rgba(0,0,0,.14);
}}
.card p {{ color: var(--muted); line-height: 1.65; margin-bottom: 0; }}
.list-card {{
  display: flex;
  gap: 12px;
  align-items: flex-start;
}}
.icon {{
  width: 34px;
  height: 34px;
  flex: 0 0 34px;
  display: grid;
  place-items: center;
  border-radius: 12px;
  background: linear-gradient(135deg, var(--primary), var(--accent));
  color: white;
  font-weight: 900;
}}
.band {{
  padding: 34px;
  border-radius: var(--radius);
  background: linear-gradient(135deg, rgba(124,58,237,.22), rgba(34,211,238,.12));
  border: 1px solid var(--line);
}}
.steps {{ counter-reset: step; }}
.step {{ position: relative; }}
.step::before {{
  counter-increment: step;
  content: counter(step);
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  margin-bottom: 16px;
  border-radius: 50%;
  background: white;
  color: #111827;
  font-weight: 900;
}}
.faq {{
  display: grid;
  gap: 12px;
}}
details {{
  background: var(--card);
  border: 1px solid var(--line);
  border-radius: 18px;
  padding: 18px 20px;
}}
summary {{
  cursor: pointer;
  font-weight: 800;
}}
details p {{
  color: var(--muted);
  line-height: 1.65;
}}
.final-cta {{
  text-align: center;
  padding: 54px 28px;
  border-radius: var(--radius);
  background:
    radial-gradient(circle at 20% 0%, color-mix(in srgb, var(--accent) 24%, transparent), transparent 24rem),
    linear-gradient(135deg, rgba(255,255,255,.12), rgba(255,255,255,.06));
  border: 1px solid var(--line);
  box-shadow: var(--shadow);
}}
.final-cta p {{
  color: var(--muted);
  max-width: 700px;
  margin: 18px auto 0;
  line-height: 1.7;
}}
.site-footer {{
  padding: 34px 0 50px;
  color: rgba(248,250,252,.62);
  font-size: 14px;
}}
.footer-row {{
  display: flex;
  justify-content: space-between;
  gap: 20px;
  border-top: 1px solid var(--line);
  padding-top: 24px;
}}
.hidden-section {{ display: none; }}

@media (max-width: 900px) {{
  .hero-grid, .grid, .media-grid {{ grid-template-columns: 1fr; }}
  .hero {{ padding-top: 56px; }}
  .mockup-screen {{ min-height: 340px; }}
  .nav-links {{ display: none; }}
  .footer-row {{ flex-direction: column; }}
}}
@media (max-width: 560px) {{
  .container {{ width: min(100% - 22px, var(--max)); }}
  .hero-actions .btn {{ width: 100%; }}
  .section {{ padding: 52px 0; }}
  .card, .band {{ padding: 20px; }}
}}
""".strip()


def render_card_item(item: Any, index: int = 0) -> str:
    if isinstance(item, dict):
        title = h(item.get("title", f"Điểm {index + 1}"))
        body = h(item.get("body", ""))
    else:
        title = h(item)
        body = ""
    body_html = f"<p>{body}</p>" if body else ""
    return f"""
<div class="card list-card">
  <div class="icon">{index + 1}</div>
  <div>
    <h3>{title}</h3>
    {body_html}
  </div>
</div>
""".strip()


def render_section(section: Dict[str, Any], spec: Dict[str, Any]) -> str:
    sid = slug(section.get("id", "section"))
    stype = section.get("type", "content")
    heading = h(section.get("heading", ""))
    body = h(section.get("body", ""))
    items = normalize_items(section.get("items", []))

    if stype == "hero":
        cta = spec.get("cta", {})
        primary_text = h(cta.get("primary_text", "Liên hệ ngay"))
        primary_url = h(cta.get("primary_url", "#contact"))
        secondary_text = h(cta.get("secondary_text", "Xem thêm"))
        secondary_url = h(cta.get("secondary_url", "#features"))
        points = "\n".join(f'<div class="hero-point">{h(x if not isinstance(x, dict) else x.get("title",""))}</div>' for x in items[:4])
        return f"""
<section class="hero" id="{sid}">
  <div class="container hero-grid">
    <div>
      <div class="eyebrow">{h(section.get("eyebrow", spec.get("brand", {}).get("tagline", "Landing Page")))}</div>
      <h1>{heading}</h1>
      <p class="lead">{body}</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="{primary_url}">{primary_text}</a>
        <a class="btn btn-secondary" href="{secondary_url}">{secondary_text}</a>
      </div>
      <div class="hero-points">{points}</div>
    </div>
    <div class="mockup" aria-label="Product preview mockup">
      <div class="mockup-screen">
        <div class="mockup-top"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>
        <div class="timeline">
          <div class="timeline-card"><strong>Input</strong><span>Ý tưởng, sản phẩm hoặc kịch bản thô</span></div>
          <div class="timeline-card"><strong>AI Workflow</strong><span>Chia cảnh, tạo prompt, voice, subtitle và render</span></div>
          <div class="timeline-card"><strong>Output</strong><span>Video ngắn sẵn sàng đăng lên nhiều nền tảng</span></div>
        </div>
      </div>
    </div>
  </div>
</section>
""".strip()

    if stype == "faq":
        faq_items = []
        for item in items:
            if isinstance(item, dict):
                faq_items.append(f"""
<details>
  <summary>{h(item.get("title", "Câu hỏi"))}</summary>
  <p>{h(item.get("body", ""))}</p>
</details>
""".strip())
            else:
                faq_items.append(f"""
<details>
  <summary>{h(item)}</summary>
  <p>Thông tin sẽ được cập nhật theo nhu cầu triển khai.</p>
</details>
""".strip())
        return f"""
<section class="section" id="{sid}">
  <div class="container">
    <div class="section-head">
      <h2>{heading}</h2>
      <p>{body}</p>
    </div>
    <div class="faq">
      {''.join(faq_items)}
    </div>
  </div>
</section>
""".strip()

    if stype == "gallery":
        cards = []
        for item in items:
            if not isinstance(item, dict):
                continue
            src = h(item.get("url", ""))
            alt = h(item.get("alt", item.get("title", "")))
            cards.append(f'''<article class="media-card">
  <img src="{src}" alt="{alt}" loading="lazy"/>
  <div class="media-copy"><h3>{h(item.get("title", ""))}</h3><p>{h(item.get("body", ""))}</p></div>
</article>''')
        return f'''<section class="section" id="{sid}">
  <div class="container">
    <div class="section-head"><h2>{heading}</h2><p>{body}</p></div>
    <div class="media-grid">{''.join(cards)}</div>
  </div>
</section>'''

    if stype == "payment":
        item = items[0] if items and isinstance(items[0], dict) else {}
        return f'''<section class="section" id="{sid}">
  <div class="container">
    <div class="section-head"><h2>{heading}</h2><p>{body}</p></div>
    <div class="payment-card">
      <img src="{h(item.get("url", ""))}" alt="{h(item.get("alt", "QR thanh toán"))}" loading="lazy"/>
      <h3>{h(item.get("title", ""))}</h3>
      <p class="section-body">{h(item.get("body", ""))}</p>
    </div>
  </div>
</section>'''

    if stype == "final_cta":
        cta = spec.get("cta", {})
        primary_text = h(cta.get("primary_text", "Liên hệ ngay"))
        primary_url = h(cta.get("primary_url", "#contact"))
        return f"""
<section class="section" id="{sid}">
  <div class="container">
    <div class="final-cta">
      <h2>{heading}</h2>
      <p>{body}</p>
      <div class="hero-actions" style="justify-content:center">
        <a class="btn btn-primary" href="{primary_url}">{primary_text}</a>
      </div>
    </div>
  </div>
</section>
""".strip()

    cards = "\n".join(render_card_item(item, i) for i, item in enumerate(items))
    grid = f'<div class="grid">{cards}</div>' if cards else ""
    wrapper_class = "band" if stype in {"problem", "proof", "pricing"} else ""
    inner_open = f'<div class="{wrapper_class}">' if wrapper_class else ""
    inner_close = "</div>" if wrapper_class else ""
    return f"""
<section class="section" id="{sid}">
  <div class="container">
    {inner_open}
    <div class="section-head">
      <h2>{heading}</h2>
      <p>{body}</p>
    </div>
    {grid}
    {inner_close}
  </div>
</section>
""".strip()


def generate_template(spec: Dict[str, Any]) -> str:
    brand = spec.get("brand", {})
    seo = spec.get("seo", {})
    cta = spec.get("cta", {})
    brand_name = h(brand.get("name", "Landing Page"))
    logo_text = h(brand.get("logo_text", brand.get("name", "LP"))[:18])
    title = h(seo.get("title", brand.get("name", "Landing Page")))
    desc = h(seo.get("description", spec.get("offer", {}).get("summary", "")))
    primary_text = h(cta.get("primary_text", "Liên hệ ngay"))
    primary_url = h(cta.get("primary_url", "#contact"))

    sections = spec.get("sections", [])
    rendered = "\n\n".join(render_section(s, spec) for s in sections)

    return f"""<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html b:css='false'
      b:defaultwidgetversion='2'
      b:layoutsVersion='3'
      b:responsive='true'
      expr:dir='data:blog.languageDirection'
      expr:lang='data:blog.locale'
      xmlns='http://www.w3.org/1999/xhtml'
      xmlns:b='http://www.google.com/2005/gml/b'
      xmlns:data='http://www.google.com/2005/gml/data'
      xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
  <meta content='width=device-width, initial-scale=1' name='viewport'/>
  <meta content='{desc}' name='description'/>
  <meta content='{title}' property='og:title'/>
  <meta content='{desc}' property='og:description'/>
  <meta content='website' property='og:type'/>
  <link expr:href='data:blog.canonicalUrl' rel='canonical'/>
  <title>{title}</title>
  <b:skin><![CDATA[
{css(spec)}
  ]]></b:skin>
</head>
<body>
  <header class="site-header">
    <div class="container nav">
      <a class="logo" href="#hero" aria-label="{brand_name}">
        <span class="logo-mark">{h((brand.get("name", "L") or "L")[0]).upper()}</span>
        <span>{logo_text}</span>
      </a>
      <nav class="nav-links" aria-label="Main navigation">
        <a href="#features">Tính năng</a>
        <a href="#workflow">Quy trình</a>
        <a href="#pricing">Demo</a>
        <a href="#faq">FAQ</a>
      </nav>
      <a class="btn btn-primary" href="{primary_url}">{primary_text}</a>
    </div>
  </header>

  <main>
{rendered}
  </main>

  <footer class="site-footer">
    <div class="container footer-row">
      <div>© <data:blog.title/>. All rights reserved.</div>
      <div>{brand_name} · Landing page powered by Blogger</div>
    </div>
  </footer>

  <b:section class='hidden-section' id='blogger-required-section' maxwidgets='1' showaddelement='false'>
    <b:widget id='Blog1' locked='true' title='Blog Posts' type='Blog' visible='false'/>
  </b:section>
</body>
</html>
"""


def generate_preview(template_xml: str) -> str:
    skin_match = re.search(r"<b:skin><!\[CDATA\[(.*?)\]\]></b:skin>", template_xml, re.S)
    css_text = skin_match.group(1).strip() if skin_match else ""

    body_match = re.search(r"<body>(.*?)</body>", template_xml, re.S)
    body = body_match.group(1).strip() if body_match else template_xml

    body = re.sub(r"<b:section.*?</b:section>", "", body, flags=re.S)
    body = body.replace("<data:blog.title/>", "Blogspot Landing Page")
    body = re.sub(r"<data:[^>]+/>", "", body)
    body = re.sub(r"\s(expr:[a-zA-Z-]+)='[^']*'", "", body)

    title_match = re.search(r"<title>(.*?)</title>", template_xml, re.S)
    title = re.sub(r"<.*?>", "", title_match.group(1)).strip() if title_match else "Landing Page Preview"

    return f"""<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{escape(title)}</title>
  <style>{css_text}</style>
</head>
<body>
{body}
</body>
</html>
"""


def has_placeholder(text: str) -> bool:
    return bool(PLACEHOLDER_RE.search(text))


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Generate Blogger landing page template from spec JSON.")
    parser.add_argument("spec", help="Path to landing-spec.json")
    parser.add_argument("outdir", help="Output directory")
    args = parser.parse_args()

    spec = load_spec(args.spec)
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)

    template = generate_template(spec)
    preview = generate_preview(template)

    (out / "landing-spec.json").write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "landing-template.xml").write_text(template, encoding="utf-8")
    (out / "preview.html").write_text(preview, encoding="utf-8")
    (out / "change-log.md").write_text(
        "# Change Log\n\n- Generated initial Blogger landing page template from landing-spec.json.\n",
        encoding="utf-8",
    )

    print(f"Generated files in {out}")


if __name__ == "__main__":
    main()
