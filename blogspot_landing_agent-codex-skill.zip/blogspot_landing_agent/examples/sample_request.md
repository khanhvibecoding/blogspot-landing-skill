# Sample Request

Tôi cần landing page cho K Studio, công cụ tạo video AI hàng loạt chỉ với 1 click.

Khách hàng là người làm content, SEO, affiliate, chủ shop nhỏ muốn tạo nhiều video ngắn từ kịch bản hoặc sản phẩm.

Tone: hiện đại, rõ ràng, hơi công nghệ.
Màu: nền tối, xanh tím.
CTA chính: Nhận demo miễn phí.
CTA URL: https://zalo.me/your-zalo-id
CTA phụ: Xem quy trình.
Không cần form. Không cần bài viết. Chỉ dùng trang chủ Blogspot.
